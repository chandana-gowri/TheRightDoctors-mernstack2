Node.js + MongoDB Atlas REST API

Steps to run:
1. Install Node.js
2. Extract this ZIP
3. Open folder in VS Code
4. Replace MongoDB Atlas connection string in server.js
5. Run:
   npm init -y
   npm install express mongoose
   node server.js

Endpoints:
GET    /person
POST   /person
PUT    /person/:id
DELETE /person/:id