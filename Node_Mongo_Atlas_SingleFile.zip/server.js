const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/*
 Replace the connection string below with your MongoDB Atlas URI
 Example:
 mongodb+srv://username:password@cluster0.mongodb.net/persondb
*/
mongoose.connect(
  'mongodb+srv://username:password@cluster0.mongodb.net/persondb',
  { useNewUrlParser: true, useUnifiedTopology: true }
).then(() => console.log("MongoDB Atlas Connected"))
 .catch(err => console.log(err));

const PersonSchema = new mongoose.Schema({
  name: String,
  age: Number,
  gender: String,
  mobile: String
});

const Person = mongoose.model('Person', PersonSchema);

// GET /person
app.get('/person', async (req, res) => {
  const people = await Person.find();
  res.json(people);
});

// POST /person
app.post('/person', async (req, res) => {
  const person = new Person(req.body);
  await person.save();
  res.json({ message: "Person added successfully" });
});

// PUT /person/:id
app.put('/person/:id', async (req, res) => {
  await Person.findByIdAndUpdate(req.params.id, req.body);
  res.json({ message: "Person updated successfully" });
});

// DELETE /person/:id
app.delete('/person/:id', async (req, res) => {
  await Person.findByIdAndDelete(req.params.id);
  res.json({ message: "Person deleted successfully" });
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});